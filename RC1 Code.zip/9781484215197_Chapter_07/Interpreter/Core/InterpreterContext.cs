﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Interpreter.Core
{
    public class InterpreterContext
    {
        public string AssemblyStore { get; set; }
        public string BasePath { get; set; }
    }
}
