﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Strategy.Core
{
    public class AppSettings
    {
        public static string SourceFolder { get; set; }
        public static string DestinationFolder { get; set; }
    }
}
