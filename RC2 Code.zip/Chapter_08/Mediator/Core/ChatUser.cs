﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Mediator.Core
{
    public class ChatUser
    {
        public string Name { get; set; }
    }
}
