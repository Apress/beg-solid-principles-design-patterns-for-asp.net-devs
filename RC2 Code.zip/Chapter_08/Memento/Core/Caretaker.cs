﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Memento.Core
{
    public class Caretaker
    {
        public static SurveySnapshot Snapshot { get; set; }
    }

}
