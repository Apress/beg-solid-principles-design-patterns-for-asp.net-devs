﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ContactManagerApp.Core
{
    public class AppSettings
    {
        public static string Title { get; set; }
        public static string ConnectionString { get; set; }
    }
}
