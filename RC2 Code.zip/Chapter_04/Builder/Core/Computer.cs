﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Builder.Core
{
    public class Computer
    {
        public List<ComputerPart> Parts { get; set; }
    }
}
